﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace DayZTypesXMLEditor
{
    class Program
    {
        static void Main(string[] args)
        {
            var typesXml = (TypesXml)new XmlSerializer(typeof(TypesXml)).Deserialize(File.OpenRead(args[0]));
            
            var newTypesXml = new TypesXml
            {
                Types = new List<Type>()
            };

            if (typesXml is null) 
            {
                Console.WriteLine("typesXml is null, tell mangosd to look at this");
                Console.ReadLine();
                return;
            }

            foreach (var type in typesXml.Types)
            {
                if (type.Name.Contains("Snow")) continue;
                if (type.Name.Contains("Tan")) continue;
                if (type.Name.Contains("CountryFlag")) continue;
                if (type.Name.Contains("Multicam")) continue;
                if (type.Name.Contains("Canteen"))
                {
                    newTypesXml.Types.Add(type);
                    continue;
                }

                var newType = new Type
                {
                    Category = type.Category,
                    Cost = type.Cost,
                    Flags = type.Flags,
                    Lifetime = "7200",
                    Min = "2",
                    Name = type.Name,
                    Nominal = "4",
                    QuantMin = "-1",
                    QuantMax = "-1",
                    Restock = "1200",
                    Usage = type.Usage,
                    Value = new List<Value>
                    {
                        new()
                        {
                            Name = "Tier3"
                        },
                        new()
                        {
                            Name = "Tier4"
                        }
                    }
                };

                newTypesXml.Types.Add(newType);
            }

            using var stringWriter = new StringWriter();
            new XmlSerializer(typeof(TypesXml)).Serialize(stringWriter, newTypesXml);

            File.WriteAllText($"output_{Path.GetFileName(args[0])}", stringWriter.ToString());
        }
    }
}
